nuke.pluginAddPath("./gizmos")
nuke.pluginAddPath("./python")
nuke.pluginAddPath("./icons")
nuke.pluginAddPath("kiss")

        
