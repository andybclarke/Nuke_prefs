
import nuke
#create Backdrop Node
bd = nuke.createNode("BackdropNode")


